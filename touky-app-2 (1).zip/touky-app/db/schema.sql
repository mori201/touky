-- ============================================================
-- TOUKY — Schéma de base de données (SQLite)
-- Plateforme de réservation de transport interurbain, Sénégal
-- ============================================================

CREATE TABLE IF NOT EXISTS regions (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  nom  TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS departements (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  region_id   INTEGER NOT NULL REFERENCES regions(id),
  nom         TEXT NOT NULL,
  UNIQUE(region_id, nom)
);

CREATE TABLE IF NOT EXISTS gares (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  departement_id   INTEGER NOT NULL REFERENCES departements(id),
  nom              TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS transporteurs (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  nom  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trajets (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  gare_depart_id   INTEGER NOT NULL REFERENCES gares(id),
  gare_arrivee_id  INTEGER NOT NULL REFERENCES gares(id),
  transporteur_id  INTEGER NOT NULL REFERENCES transporteurs(id),
  heure_depart     TEXT NOT NULL,          -- 'HH:MM'
  duree_minutes    INTEGER NOT NULL,
  prix             INTEGER NOT NULL,       -- en FCFA
  places_totales   INTEGER NOT NULL DEFAULT 16
);

CREATE TABLE IF NOT EXISTS utilisateurs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  nom         TEXT,
  telephone   TEXT NOT NULL UNIQUE,
  created_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reservations (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  reference          TEXT NOT NULL UNIQUE,
  utilisateur_id     INTEGER NOT NULL REFERENCES utilisateurs(id),
  trajet_id          INTEGER NOT NULL REFERENCES trajets(id),
  date_voyage        TEXT NOT NULL,        -- 'YYYY-MM-DD'
  nb_places          INTEGER NOT NULL,
  sieges             TEXT NOT NULL,        -- JSON: "[2,3]"
  montant_total      INTEGER NOT NULL,
  methode_paiement   TEXT,
  statut             TEXT NOT NULL DEFAULT 'confirmee', -- attente | confirmee | refusee | annulee
  created_at         TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_departements_region ON departements(region_id);
CREATE INDEX IF NOT EXISTS idx_gares_departement ON gares(departement_id);
CREATE INDEX IF NOT EXISTS idx_trajets_depart ON trajets(gare_depart_id);
CREATE INDEX IF NOT EXISTS idx_trajets_arrivee ON trajets(gare_arrivee_id);
CREATE INDEX IF NOT EXISTS idx_reservations_trajet_date ON reservations(trajet_id, date_voyage);
CREATE INDEX IF NOT EXISTS idx_reservations_user ON reservations(utilisateur_id);
