// ============================================================
// TOUKY — Script d'initialisation & de peuplement de la base
// Usage : node db/seed.js
// ============================================================
import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, "touky.db");
const SCHEMA_PATH = path.join(__dirname, "schema.sql");

// Les 14 régions du Sénégal et leurs départements officiels (45 au total)
export const REGIONS = {
  "Dakar": ["Dakar", "Guédiawaye", "Pikine", "Rufisque"],
  "Thiès": ["Mbour", "Thiès", "Tivaouane"],
  "Diourbel": ["Bambey", "Diourbel", "Mbacké"],
  "Fatick": ["Fatick", "Foundiougne", "Gossas"],
  "Kaolack": ["Guinguinéo", "Kaolack", "Nioro du Rip"],
  "Kaffrine": ["Birkelane", "Kaffrine", "Koungheul", "Malem Hodar"],
  "Louga": ["Kébémer", "Linguère", "Louga"],
  "Saint-Louis": ["Dagana", "Podor", "Saint-Louis"],
  "Matam": ["Kanel", "Matam", "Ranérou Ferlo"],
  "Tambacounda": ["Bakel", "Goudiry", "Koumpentoum", "Tambacounda"],
  "Kédougou": ["Kédougou", "Salémata", "Saraya"],
  "Kolda": ["Kolda", "Médina Yoro Foulah", "Vélingara"],
  "Sédhiou": ["Bounkiling", "Goudomp", "Sédhiou"],
  "Ziguinchor": ["Bignona", "Oussouye", "Ziguinchor"],
};

const TRANSPORTEURS = [
  "Kolda Express", "Car Rapide Fouta", "Ndiaga Ndiaye Casamance",
  "Tata Sénégal Bus", "Baol Transport", "Petit Karim Voyages", "Sénégal Dem Dikk",
];

const CRENEAUX = ["06:30", "13:00"]; // deux départs / jour entre chaque paire de capitales

function run() {
  if (fs.existsSync(DB_PATH)) fs.unlinkSync(DB_PATH);
  const db = new DatabaseSync(DB_PATH);
  db.exec(fs.readFileSync(SCHEMA_PATH, "utf8"));

  const insertRegion = db.prepare("INSERT INTO regions (nom) VALUES (?)");
  const insertDept = db.prepare("INSERT INTO departements (region_id, nom) VALUES (?, ?)");
  const insertGare = db.prepare("INSERT INTO gares (departement_id, nom) VALUES (?, ?)");
  const insertTransp = db.prepare("INSERT INTO transporteurs (nom) VALUES (?)");
  const insertTrajet = db.prepare(
    `INSERT INTO trajets (gare_depart_id, gare_arrivee_id, transporteur_id, heure_depart, duree_minutes, prix, places_totales)
     VALUES (?, ?, ?, ?, ?, ?, 16)`
  );

  const regionId = {};
  const deptId = {};      // "Region::Departement" -> id
  const gareId = {};      // deptId -> gare id
  const capitalDeptId = {}; // region -> departement id (chef-lieu, même nom que la région)

  for (const region of Object.keys(REGIONS)) {
    const info = insertRegion.run(region);
    regionId[region] = Number(info.lastInsertRowid);
  }

  for (const [region, depts] of Object.entries(REGIONS)) {
    for (const dept of depts) {
      const info = insertDept.run(regionId[region], dept);
      const id = Number(info.lastInsertRowid);
      deptId[`${region}::${dept}`] = id;
      const gInfo = insertGare.run(id, `Gare Routière de ${dept}`);
      gareId[id] = Number(gInfo.lastInsertRowid);
      if (dept === region) capitalDeptId[region] = id; // le département "capitale" porte le nom de la région
    }
  }

  const transpId = TRANSPORTEURS.map((nom) => Number(insertTransp.run(nom).lastInsertRowid));

  // Trajets : maillage complet entre les 14 gares "chef-lieu" de région (lignes nationales réelles)
  const capitals = Object.values(capitalDeptId);
  let trajetsCreated = 0;
  for (const depDeptId of capitals) {
    for (const arrDeptId of capitals) {
      if (depDeptId === arrDeptId) continue;
      for (const heure of CRENEAUX) {
        const transporteur = transpId[Math.floor(Math.random() * transpId.length)];
        const duree = 90 + Math.floor(Math.random() * 8) * 60; // 1h30 à 8h30
        const prix = 2000 + Math.floor(Math.random() * 14) * 500; // 2000 à 9000 F
        insertTrajet.run(gareId[depDeptId], gareId[arrDeptId], transporteur, heure, duree, prix);
        trajetsCreated++;
      }
    }
  }

  // Utilisateur et réservations de démonstration (pour que les tableaux de bord ne soient pas vides)
  const insertUser = db.prepare("INSERT INTO utilisateurs (nom, telephone) VALUES (?, ?)");
  const demoUserId = Number(insertUser.run("Aïssatou Ndiaye", "+221770000000").lastInsertRowid);

  const insertRes = db.prepare(
    `INSERT INTO reservations (reference, utilisateur_id, trajet_id, date_voyage, nb_places, sieges, montant_total, methode_paiement, statut)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const someTrajets = db.prepare("SELECT id, prix FROM trajets LIMIT 6").all();
  const demoStatuts = ["attente", "attente", "confirmee", "attente", "confirmee", "attente"];
  const today = new Date().toISOString().slice(0, 10);
  someTrajets.forEach((t, i) => {
    const places = 1 + (i % 3);
    const sieges = Array.from({ length: places }, (_, k) => k + 1);
    insertRes.run(
      `SN-${1000 + i}-DEMO`,
      demoUserId,
      t.id,
      today,
      places,
      JSON.stringify(sieges),
      t.prix * places,
      "orange",
      demoStatuts[i]
    );
  });

  console.log(`✅ Base initialisée : ${Object.keys(REGIONS).length} régions, ${Object.keys(deptId).length} départements, ${Object.keys(gareId).length} gares, ${trajetsCreated} trajets.`);
  db.close();
}

run();
