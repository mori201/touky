// ============================================================
// TOUKY — Serveur backend
// Node.js natif (http + node:sqlite) — AUCUNE dépendance npm requise
// Usage : node server.js   →   http://localhost:3000
// ============================================================
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, "db", "touky.db");
const PUBLIC_DIR = path.join(__dirname, "public");
const PORT = process.env.PORT || 3000;

if (!fs.existsSync(DB_PATH)) {
  console.error("❌ Base de données introuvable. Lancez d'abord : node db/seed.js");
  process.exit(1);
}
const db = new DatabaseSync(DB_PATH);

/* ------------------------- Helpers ------------------------- */

function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,PATCH,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => (data += chunk));
    req.on("end", () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
    });
    req.on("error", reject);
  });
}

function genReference(deptArrivee) {
  const code = (deptArrivee || "SEN").normalize("NFD").replace(/[\u0300-\u036f]/g, "").slice(0, 3).toUpperCase();
  return `SN-${Math.floor(1000 + Math.random() * 9000)}-${code}`;
}

// Résout la "gare effective" d'un département : si c'est un chef-lieu de région, sa propre
// gare ; sinon, la gare du chef-lieu de sa région (gare la plus proche), comme décrit dans
// le parcours utilisateur (géolocalisation → gare la plus proche).
function gareEffective(departementId) {
  const dept = db.prepare(
    `SELECT d.id, d.nom, d.region_id, r.nom AS region_nom
     FROM departements d JOIN regions r ON r.id = d.region_id WHERE d.id = ?`
  ).get(departementId);
  if (!dept) return null;

  const findGare = (depId) => db.prepare(
    `SELECT g.id, g.nom, d.nom AS departement, r.nom AS region, 0 as distance
     FROM gares g JOIN departements d ON d.id = g.departement_id JOIN regions r ON r.id = d.region_id
     WHERE g.departement_id = ?`
  ).get(depId);

  if (dept.nom === dept.region_nom) {
    return findGare(dept.id); // c'est le chef-lieu : gare directe, distance 0
  }
  const capitale = db.prepare(`SELECT id FROM departements WHERE region_id = ? AND nom = ?`).get(dept.region_id, dept.region_nom);
  const gare = findGare(capitale.id);
  if (gare) gare.distance = Number((0.8 + Math.random() * 5.7).toFixed(1));
  return gare;
}

function seatsOccupied(trajetId, dateVoyage) {
  const rows = db.prepare(
    `SELECT sieges FROM reservations WHERE trajet_id = ? AND date_voyage = ? AND statut NOT IN ('refusee','annulee')`
  ).all(trajetId, dateVoyage);
  const occupied = [];
  for (const r of rows) {
    try { JSON.parse(r.sieges).forEach((s) => occupied.push(s)); } catch { /* ignore */ }
  }
  return occupied;
}

/* ------------------------- Routes API ------------------------- */

const routes = [];
function route(method, pattern, handler) {
  const keys = [];
  const regex = new RegExp(
    "^" + pattern.replace(/:[^/]+/g, (m) => { keys.push(m.slice(1)); return "([^/]+)"; }) + "$"
  );
  routes.push({ method, regex, keys, handler });
}

route("GET", "/api/regions", async (req, res) => {
  const regions = db.prepare("SELECT id, nom FROM regions ORDER BY nom").all();
  const depts = db.prepare("SELECT id, region_id, nom FROM departements ORDER BY nom").all();
  const result = regions.map((r) => ({
    ...r,
    departements: depts.filter((d) => d.region_id === r.id),
  }));
  sendJSON(res, 200, result);
});

route("GET", "/api/gares", async (req, res) => {
  const gares = db.prepare(
    `SELECT g.id, g.nom, d.nom AS departement, r.nom AS region
     FROM gares g JOIN departements d ON d.id = g.departement_id JOIN regions r ON r.id = d.region_id
     ORDER BY r.nom, d.nom`
  ).all();
  sendJSON(res, 200, gares);
});

route("GET", "/api/stats", async (req, res) => {
  const regions = db.prepare("SELECT COUNT(*) c FROM regions").get().c;
  const departements = db.prepare("SELECT COUNT(*) c FROM departements").get().c;
  const gares = db.prepare("SELECT COUNT(*) c FROM gares").get().c;
  const trajets = db.prepare("SELECT COUNT(*) c FROM trajets").get().c;
  const reservations = db.prepare("SELECT COUNT(*) c FROM reservations WHERE statut != 'refusee'").get().c;
  const revenus = db.prepare("SELECT COALESCE(SUM(montant_total),0) s FROM reservations WHERE statut = 'confirmee'").get().s;
  sendJSON(res, 200, { regions, departements, gares, trajets, reservations, revenus });
});

route("POST", "/api/auth/login", async (req, res) => {
  const body = await readBody(req);
  const telephone = (body.telephone || "").trim();
  if (!telephone) return sendJSON(res, 400, { error: "Numéro de téléphone requis" });
  let user = db.prepare("SELECT * FROM utilisateurs WHERE telephone = ?").get(telephone);
  if (!user) {
    const info = db.prepare("INSERT INTO utilisateurs (nom, telephone) VALUES (?, ?)").run(body.nom || "Voyageur TOUKY", telephone);
    user = db.prepare("SELECT * FROM utilisateurs WHERE id = ?").get(Number(info.lastInsertRowid));
  }
  sendJSON(res, 200, user);
});

route("GET", "/api/trajets/search", async (req, res, params, query) => {
  const depId = Number(query.get("depart"));
  const arrId = Number(query.get("arrivee"));
  const date = query.get("date");
  if (!depId || !arrId || !date) return sendJSON(res, 400, { error: "Paramètres manquants (depart, arrivee, date)" });

  const gareDepart = gareEffective(depId);
  const gareArrivee = gareEffective(arrId);
  if (!gareDepart || !gareArrivee) return sendJSON(res, 404, { error: "Département introuvable" });

  const trajets = db.prepare(
    `SELECT t.id, t.heure_depart, t.duree_minutes, t.prix, t.places_totales, tr.nom AS transporteur
     FROM trajets t JOIN transporteurs tr ON tr.id = t.transporteur_id
     WHERE t.gare_depart_id = ? AND t.gare_arrivee_id = ?
     ORDER BY t.heure_depart`
  ).all(gareDepart.id, gareArrivee.id);

  const enriched = trajets.map((t) => {
    const occupied = seatsOccupied(t.id, date);
    return { ...t, seatsTaken: occupied, seatsRemaining: t.places_totales - occupied.length };
  });

  sendJSON(res, 200, { gareDepart, gareArrivee, trajets: enriched });
});

route("GET", "/api/trajets/:id/sieges", async (req, res, params, query) => {
  const date = query.get("date");
  const occupied = seatsOccupied(Number(params.id), date);
  sendJSON(res, 200, { occupied });
});

route("POST", "/api/reservations", async (req, res) => {
  const body = await readBody(req);
  const { utilisateur_id, trajet_id, date_voyage, sieges, methode_paiement } = body;
  if (!utilisateur_id || !trajet_id || !date_voyage || !Array.isArray(sieges) || sieges.length === 0) {
    return sendJSON(res, 400, { error: "Champs requis manquants" });
  }
  const trajet = db.prepare(
    `SELECT t.*, ga.nom AS gare_arrivee_nom, gd.nom AS gare_depart_nom, tr.nom AS transporteur
     FROM trajets t
     JOIN gares ga ON ga.id = t.gare_arrivee_id
     JOIN gares gd ON gd.id = t.gare_depart_id
     JOIN transporteurs tr ON tr.id = t.transporteur_id
     WHERE t.id = ?`
  ).get(trajet_id);
  if (!trajet) return sendJSON(res, 404, { error: "Trajet introuvable" });

  const occupied = seatsOccupied(trajet_id, date_voyage);
  const conflict = sieges.find((s) => occupied.includes(s));
  if (conflict) return sendJSON(res, 409, { error: `Le siège ${conflict} vient d'être réservé, veuillez en choisir un autre.` });

  const reference = genReference(trajet.gare_arrivee_nom);
  const montant = trajet.prix * sieges.length;
  const info = db.prepare(
    `INSERT INTO reservations (reference, utilisateur_id, trajet_id, date_voyage, nb_places, sieges, montant_total, methode_paiement, statut)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'confirmee')`
  ).run(reference, utilisateur_id, trajet_id, date_voyage, sieges.length, JSON.stringify(sieges), montant, methode_paiement || null);

  const reservation = db.prepare("SELECT * FROM reservations WHERE id = ?").get(Number(info.lastInsertRowid));
  sendJSON(res, 201, { ...reservation, sieges: JSON.parse(reservation.sieges), trajet });
});

route("GET", "/api/reservations", async (req, res, params, query) => {
  const userId = Number(query.get("utilisateur_id"));
  if (!userId) return sendJSON(res, 400, { error: "utilisateur_id requis" });
  const rows = db.prepare(
    `SELECT r.*, t.heure_depart, t.duree_minutes, tr.nom AS transporteur, gd.nom AS gare_depart_nom, ga.nom AS gare_arrivee_nom
     FROM reservations r
     JOIN trajets t ON t.id = r.trajet_id
     JOIN transporteurs tr ON tr.id = t.transporteur_id
     JOIN gares gd ON gd.id = t.gare_depart_id
     JOIN gares ga ON ga.id = t.gare_arrivee_id
     WHERE r.utilisateur_id = ?
     ORDER BY r.created_at DESC`
  ).all(userId);
  sendJSON(res, 200, rows.map((r) => ({ ...r, sieges: JSON.parse(r.sieges) })));
});

route("GET", "/api/gare/:gareId/reservations", async (req, res, params) => {
  const gareId = Number(params.gareId);
  const rows = db.prepare(
    `SELECT r.*, t.heure_depart, tr.nom AS transporteur, ga.nom AS gare_arrivee_nom, u.nom AS client_nom, u.telephone
     FROM reservations r
     JOIN trajets t ON t.id = r.trajet_id
     JOIN transporteurs tr ON tr.id = t.transporteur_id
     JOIN gares ga ON ga.id = t.gare_arrivee_id
     JOIN utilisateurs u ON u.id = r.utilisateur_id
     WHERE t.gare_depart_id = ?
     ORDER BY r.created_at DESC`
  ).all(gareId);
  sendJSON(res, 200, rows.map((r) => ({ ...r, sieges: JSON.parse(r.sieges) })));
});

route("PATCH", "/api/reservations/:id", async (req, res, params) => {
  const body = await readBody(req);
  const statut = body.statut;
  if (!["attente", "confirmee", "refusee", "annulee"].includes(statut)) {
    return sendJSON(res, 400, { error: "Statut invalide" });
  }
  db.prepare("UPDATE reservations SET statut = ? WHERE id = ?").run(statut, Number(params.id));
  const updated = db.prepare("SELECT * FROM reservations WHERE id = ?").get(Number(params.id));
  sendJSON(res, 200, updated);
});

/* ------------------------- Fichiers statiques (frontend) ------------------------- */

const MIME = { ".html": "text/html", ".css": "text/css", ".js": "application/javascript", ".json": "application/json", ".svg": "image/svg+xml" };

function serveStatic(req, res) {
  let filePath = req.url === "/" ? "/index.html" : req.url;
  filePath = path.join(PUBLIC_DIR, decodeURIComponent(filePath.split("?")[0]));
  if (!filePath.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end("Interdit"); }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      fs.readFile(path.join(PUBLIC_DIR, "index.html"), (e2, indexData) => {
        if (e2) { res.writeHead(404); return res.end("Introuvable"); }
        res.writeHead(200, { "Content-Type": "text/html" });
        res.end(indexData);
      });
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(data);
  });
}

/* ------------------------- Serveur HTTP ------------------------- */

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET,POST,PATCH,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    });
    return res.end();
  }

  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname.startsWith("/api/")) {
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const match = r.regex.exec(url.pathname);
      if (!match) continue;
      const params = {};
      r.keys.forEach((k, i) => (params[k] = match[i + 1]));
      try {
        await r.handler(req, res, params, url.searchParams);
      } catch (e) {
        console.error(e);
        sendJSON(res, 500, { error: "Erreur serveur", detail: e.message });
      }
      return;
    }
    return sendJSON(res, 404, { error: "Route API introuvable" });
  }

  serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`🚌 TOUKY backend prêt sur http://localhost:${PORT}`);
});
