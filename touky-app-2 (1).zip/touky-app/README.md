# 🚌 TOUKY — Réservation de transport interurbain au Sénégal

Application complète **front-end + back-end + base de données SQL**, prête à installer et
utiliser en local. Couvre les **14 régions et 45 départements** du Sénégal.

## Ce que contient le projet

```
touky-app/
├── server.js          → Backend (Node.js natif : http + node:sqlite). Sert aussi le frontend.
├── db/
│   ├── schema.sql      → Schéma SQL (régions, départements, gares, transporteurs, trajets, utilisateurs, réservations)
│   ├── seed.js          → Script qui crée et peuple la base avec les données réelles du Sénégal
│   └── touky.db         → Base SQLite (générée par seed.js)
├── public/             → Frontend (HTML + CSS + JavaScript natif, sans framework)
│   ├── index.html
│   ├── style.css
│   └── app.js
└── package.json
```

## Prérequis — UNE SEULE CHOSE À INSTALLER

- **Node.js version 22.5 ou plus récente** (https://nodejs.org)

Aucune autre dépendance : pas de npm install obligatoire, pas de base de données à
installer séparément (SQLite est intégré nativement à Node.js via le module `node:sqlite`).

Vérifiez votre version :
```bash
node --version
```

## Installation & lancement (3 commandes)

```bash
# 1. Se placer dans le dossier du projet
cd touky-app

# 2. Créer et peupler la base de données (régions, départements, gares, trajets…)
node db/seed.js

# 3. Démarrer le serveur
node server.js
```

Puis ouvrez votre navigateur à l'adresse :

**http://localhost:3000**

L'application s'ouvre directement — pas de build, pas de compilation, pas de configuration.

> Vous pouvez aussi utiliser `npm run init-db` puis `npm start` si vous préférez passer par npm
> (dans ce cas `npm install` ne fera rien de spécial car il n'y a aucune dépendance externe).

## Fonctionnalités disponibles

### Espace Voyageur (app mobile)
- Connexion par numéro de téléphone (création automatique de compte)
- Recherche de trajet avec sélection **région → département** (départ et arrivée) parmi les
  14 régions / 45 départements
- Détection automatique de la « gare la plus proche » : si le département choisi n'est pas
  une capitale régionale, l'app route vers la gare de la région correspondante
- Résultats de trajets réels, avec horaires, prix, durée et places disponibles calculées
  dynamiquement à partir des réservations déjà en base
- Sélection de sièges (grille de 16 places, mise à jour en temps réel selon les réservations
  existantes pour la date choisie)
- Paiement simulé (Orange Money / Wave / Free Money / Carte bancaire)
- Génération d'un e-ticket avec référence unique
- Historique des réservations, notifications, profil

### Espace Gare routière
- Sélection de la gare à superviser (liste des 45 gares)
- Liste des réservations reçues pour cette gare, avec confirmation / refus en un clic
  (mise à jour immédiate en base de données)

### Back-office Admin
- Statistiques globales (régions, départements, trajets, revenus confirmés)
- Annuaire complet des gares, avec recherche par région ou département

## Base de données — modèle relationnel (SQL)

| Table          | Rôle                                                              |
|----------------|--------------------------------------------------------------------|
| `regions`      | Les 14 régions du Sénégal                                          |
| `departements` | Les 45 départements, rattachés à une région                        |
| `gares`        | Une gare routière par département                                  |
| `transporteurs`| Compagnies de transport                                            |
| `trajets`      | Lignes régulières entre gares (maillage entre les 14 capitales régionales) |
| `utilisateurs` | Comptes voyageurs (créés automatiquement à la connexion)            |
| `reservations` | Réservations : sièges (JSON), montant, statut, moyen de paiement    |

Le schéma complet est dans `db/schema.sql`. Vous pouvez l'inspecter ou l'adapter librement.

Pour repartir d'une base vierge à tout moment :
```bash
node db/seed.js
```
(cela supprime et recrée entièrement `db/touky.db`)

## Réinitialiser uniquement les réservations

Si vous voulez garder régions/départements/gares/trajets mais repartir sans réservations,
relancez simplement `node db/seed.js` — cela régénère tout depuis zéro (quelques réservations
de démonstration sont recréées automatiquement pour que les tableaux de bord ne soient pas vides).

## Limites connues (version MVP)

- Le paiement est **simulé** : aucune connexion réelle à Orange Money / Wave / Free Money.
- L'OTP de connexion n'est pas envoyé par SMS : la connexion se fait directement par numéro
  de téléphone (utile pour une démonstration locale).
- Le module natif `node:sqlite` est expérimental dans Node.js (avertissement au démarrage,
  sans impact sur le fonctionnement).
- Pas encore d'application chauffeur (scan QR à l'embarquement) — prévue dans l'architecture
  mais non codée dans cette version.

## Pour aller plus loin

- Remplacer le paiement simulé par les API réelles d'Orange Money / Wave.
- Ajouter l'envoi de vrais SMS/OTP (Twilio ou opérateur local).
- Déployer le serveur sur un hébergeur (Render, Railway, VPS) pour un accès en ligne.
- Ajouter un vrai système d'authentification (mot de passe, session, rôles gare/admin protégés).
''EOF''
echo "README créé"